#menu-to-edit .menu-item .field-image img {
	width: 16px;
	height: auto;
}
#menu-to-edit .menu-item .rdtheme-menu-icon-spinner {
	animation: rdtheme-dashicons-spin 1s infinite;
	animation-timing-function: linear;
	vertical-align: middle;
	display: none;
}
@keyframes rdtheme-dashicons-spin {
	0% {
		transform: rotate( 0deg );
	}
	100% {
		transform: rotate( 360deg );
	}
}