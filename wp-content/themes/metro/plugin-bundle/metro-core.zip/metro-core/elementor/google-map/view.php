<?php
/**
 * This file can be overridden by copying it to yourtheme/elementor-custom/google-map/view.php
 * 
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Metro_Core;
?>
<div class="rt-el-google-map">
	<?php echo $data['iframe'];?>
</div>